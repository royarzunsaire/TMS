using System.Collections.Generic; 
namespace teset{ 

    public class Root
    {
        public List<Item> items { get; set; }
        public List<object> warnings { get; set; }
    }

}