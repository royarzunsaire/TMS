using System.Collections.Generic; 
namespace teset{ 

    public class Root
    {
        public int completedcount { get; set; }
        public int itemscount { get; set; }
        public List<Itemsdata> itemsdata { get; set; }
        public List<object> warnings { get; set; }
    }

}