using System.Collections.Generic; 
namespace teset{ 

    public class Itemsdata
    {
        public Item item { get; set; }
        public List<string> data { get; set; }
    }

}