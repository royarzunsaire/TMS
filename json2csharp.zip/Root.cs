using System.Collections.Generic; 
namespace teset{ 

    public class Root
    {
        public List<Feedback> feedbacks { get; set; }
        public List<object> warnings { get; set; }
    }

}